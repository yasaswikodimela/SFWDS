package food.donation;

import food.utils.DonationLog;

/**
 * Thread to simulate a single donation pickup and delivery.
 */
public class DonationThread extends Thread {
    private Volunteer volunteer;
    private FoodItem food;
    private Donor donor;
    private NGO ngo;

    public DonationThread(Volunteer volunteer, FoodItem food, Donor donor, NGO ngo) {
        this.volunteer = volunteer;
        this.food = food;
        this.donor = donor;
        this.ngo = ngo;
    }

    @Override
    public void run() {
        try {
            // Simulate pickup action
            volunteer.pickup(food, donor, ngo);

            // Simulate time taken for transit & delivery
            Thread.sleep(1500 + (long)(Math.random() * 2000));

            // Log success
            String logEntry = String.format("Food '%s' (%.2fkg) from %s delivered to %s by %s",
                    food.getName(), food.getQuantityKg(), donor.getDonorName(), ngo.getNgoName(), volunteer.getName());
            DonationLog.saveLog(logEntry);

            System.out.println("DONE: " + logEntry);
        } catch (InterruptedException e) {
            System.out.println("Delivery interrupted: " + e.getMessage());
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            System.out.println("Delivery error: " + e.getMessage());
            try {
                DonationLog.saveLog("ERROR during delivery: " + e.getMessage());
            } catch (Exception ex) {
                // ignore logging failure
            }
        }
    }
}
