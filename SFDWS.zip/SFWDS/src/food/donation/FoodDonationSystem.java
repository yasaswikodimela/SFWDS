package food.donation;

import food.utils.DonationLog;
import food.utils.ExpiredFoodException;

import java.util.ArrayList;
import java.util.List;

/**
 * Main class to simulate donation registrations and dispatch volunteers.
 */
public class FoodDonationSystem {

    public static void main(String[] args) {
        System.out.println("Starting Smart Food Waste Reduction and Donation System (SFWDS) simulation...");

        // Sample donors, NGOs and volunteers
        Donor d1 = new Donor("The Green Cafe", "MG Road");
        Donor d2 = new Donor("EventX Catering", "City Hall");

        NGO ngo1 = new NGO("HelpingHands", "Central Park");
        NGO ngo2 = new NGO("CommunityCare", "North Zone");

        Volunteer v1 = new Volunteer("Rohan", 201, "9999999991");
        Volunteer v2 = new Volunteer("Neha", 202, "9999999992");
        Volunteer v3 = new Volunteer("Asha", 203, "9999999993");

        // Create some FoodItems: note one expired example (hoursUntilExpiry <= 0)
        FoodItem f1 = new FoodItem(1, "Rice Biryani", 8.5, true, 6);
        FoodItem f2 = new FoodItem(2, "Vegetable Salad", 3.0, true, 1);
        FoodItem f3 = new FoodItem(3, "Bread Packs", 10.0, false, 0); // non-perishable
        FoodItem f4 = new FoodItem(4, "Milk (tray)", 5.0, true, -2); // expired example

        // Collections to represent queues/lists
        List<Donor> donors = new ArrayList<>();
        List<NGO> ngos = new ArrayList<>();
        List<Volunteer> volunteers = new ArrayList<>();
        donors.add(d1); donors.add(d2);
        ngos.add(ngo1); ngos.add(ngo2);
        volunteers.add(v1); volunteers.add(v2); volunteers.add(v3);

        // Register donations (simple matching algorithm: round-robin)
        System.out.println("Registering donations...");

        List<DonationThread> threads = new ArrayList<>();
        try {
            threads.add(scheduleDonation(f1, d1, ngo1, volunteers.get(0)));
            threads.add(scheduleDonation(f2, d2, ngo2, volunteers.get(1)));
            threads.add(scheduleDonation(f3, d1, ngo2, volunteers.get(2)));

            // f4 is expired — should throw ExpiredFoodException
            try {
                threads.add(scheduleDonation(f4, d2, ngo1, volunteers.get(0)));
            } catch (ExpiredFoodException e) {
                System.out.println("Rejected donation: " + e.getMessage());
                DonationLog.saveLog("REJECTED: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error scheduling donations: " + e.getMessage());
        }

        // Start all donation threads
        System.out.println("Starting pickup threads...");
        for (DonationThread dt : threads) dt.start();

        // Wait for completion
        for (DonationThread dt : threads) {
            try {
                dt.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        System.out.println("All scheduled donations processed. Check donation_log.txt for records.");
    }

    /**
     * Schedule donation: validates food and returns a DonationThread ready to run.
     */
    private static DonationThread scheduleDonation(FoodItem food, Donor donor, NGO ngo, Volunteer volunteer)
            throws ExpiredFoodException {
        // Validate perishable items
        if (food.isPerishable() && food.getHoursUntilExpiry() <= 0) {
            throw new ExpiredFoodException("Food '" + food.getName() + "' (ID:" + food.getId() + ") is expired and cannot be donated.");
        }

        // Possibly other validations (quantity > 0, contact, area match etc.)
        String registerMsg = String.format("Registered donation: %s from %s for %s — assigned to %s",
                food.getName(), donor.getDonorName(), ngo.getNgoName(), volunteer.getName());
        System.out.println(registerMsg);
        try {
            DonationLog.saveLog(registerMsg);
        } catch (Exception e) {
            System.out.println("Warning: failed to write registration log: " + e.getMessage());
        }

        return new DonationThread(volunteer, food, donor, ngo);
    }
}
