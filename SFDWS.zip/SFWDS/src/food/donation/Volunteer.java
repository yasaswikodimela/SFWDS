package food.donation;

/**
 * Volunteer who picks up donated food and delivers to an NGO.
 */
public class Volunteer implements Deliverable {
    private String name;
    private int id;
    private String contact; // optional

    public Volunteer(String name, int id, String contact) {
        this.name = name;
        this.id = id;
        this.contact = contact;
    }

    public String getName() { return name; }
    public int getId() { return id; }

    @Override
    public void pickup(FoodItem food, Donor donor, NGO ngo) throws Exception {
        // In real world: check permissions, vehicle, temperature control etc.
        System.out.printf("%s (volunteer) is picking up %s from %s to deliver to %s%n",
                name, food.getName(), donor.getDonorName(), ngo.getNgoName());
    }

    @Override
    public String toString() {
        return name + " (ID:" + id + ")";
    }
}
