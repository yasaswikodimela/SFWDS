package food.donation;

/**
 * Represents a receiving NGO / community center.
 */
public class NGO {
    private String ngoName;
    private String area;

    public NGO(String ngoName, String area) {
        this.ngoName = ngoName;
        this.area = area;
    }

    public String getNgoName() { return ngoName; }
    public String getArea() { return area; }

    @Override
    public String toString() {
        return ngoName + " [" + area + "]";
    }
}
