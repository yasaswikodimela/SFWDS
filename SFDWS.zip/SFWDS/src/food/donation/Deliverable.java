package food.donation;

/**
 * Interface for pickup/delivery behavior.
 */
public interface Deliverable {
    void pickup(FoodItem food, Donor donor, NGO ngo) throws Exception;
}
