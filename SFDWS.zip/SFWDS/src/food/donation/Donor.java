package food.donation;

/**
 * Represents a food donor - can be a restaurant, event organizer, etc.
 */
public class Donor {
    private String donorName;
    private String location;

    public Donor(String donorName, String location) {
        this.donorName = donorName;
        this.location = location;
    }

    public String getDonorName() { return donorName; }
    public String getLocation() { return location; }

    @Override
    public String toString() {
        return donorName + " (" + location + ")";
    }
}
