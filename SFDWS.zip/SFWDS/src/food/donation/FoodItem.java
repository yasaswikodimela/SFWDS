package food.donation;

/**
 * Represents a food item offered for donation.
 */
public class FoodItem {
    private int id;
    private String name;
    private double quantityKg;
    private boolean perishable;
    private int hoursUntilExpiry; // approximate hours remaining; <=0 => expired

    public FoodItem(int id, String name, double quantityKg, boolean perishable, int hoursUntilExpiry) {
        this.id = id;
        this.name = name;
        this.quantityKg = quantityKg;
        this.perishable = perishable;
        this.hoursUntilExpiry = hoursUntilExpiry;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getQuantityKg() { return quantityKg; }
    public boolean isPerishable() { return perishable; }
    public int getHoursUntilExpiry() { return hoursUntilExpiry; }

    @Override
    public String toString() {
        return String.format("FoodItem[id=%d, name=%s, qty=%.2fkg, perishable=%b, hoursUntilExpiry=%d]",
                id, name, quantityKg, perishable, hoursUntilExpiry);
    }
}
