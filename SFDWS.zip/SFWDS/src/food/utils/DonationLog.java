package food.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Simple utility to write donation logs to a file (append mode).
 */
public class DonationLog {
    private static final String LOG_FILE = "donation_log.txt";
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static synchronized void saveLog(String entry) throws IOException {
        try (FileWriter fw = new FileWriter(LOG_FILE, true);
             PrintWriter pw = new PrintWriter(fw)) {
            String timestamp = LocalDateTime.now().format(dtf);
            pw.println(timestamp + " | " + entry);
        }
    }
}
