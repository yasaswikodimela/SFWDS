package food.utils;

/**
 * Custom exception thrown when food is expired or unsafe.
 */
public class ExpiredFoodException extends Exception {
    public ExpiredFoodException(String message) {
        super(message);
    }
}
